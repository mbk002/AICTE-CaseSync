import { useState } from "react";
import {
  Activity, ArrowRight, Building2, CheckCircle2, CircleHelp,
  FileText, Landmark, LockKeyhole, ShieldCheck, Sparkles, Users,
} from "lucide-react";

type Role = "institution" | "officer" | "admin";

type DemoAccount = {
  role: Role;
  label: string;
  email: string;
  description: string;
  icon: typeof Building2;
};

const DEMO_PASSWORD = "casesync-demo";

const accounts: DemoAccount[] = [
  {
    role: "institution",
    label: "Institution",
    email: "institution@demo.casesync",
    description: "Submit complaints and track their progress",
    icon: Building2,
  },
  {
    role: "officer",
    label: "Bureau / Cell Officer",
    email: "officer@demo.casesync",
    description: "Review assigned cases and coordinate action",
    icon: Users,
  },
  {
    role: "admin",
    label: "AICTE Administrator",
    email: "admin@demo.casesync",
    description: "Monitor cross-bureau operations and escalations",
    icon: Landmark,
  },
];

function RoleHome({ role, onSignOut }: { role: Role; onSignOut: () => void }) {
  const account = accounts.find((item) => item.role === role)!;
  const Icon = account.icon;
  const nextSteps: Record<Role, string[]> = {
    institution: [
      "Complaint submission and evidence checklist",
      "Case timeline and clarification requests",
      "Resolution status and communication history",
    ],
    officer: [
      "Assigned case queue and triage decisions",
      "Cross-bureau tasks and handoffs",
      "SLA risk review and resolution checks",
    ],
    admin: [
      "Cross-bureau case monitoring",
      "Backlog and deadline risk overview",
      "Audit history and workload analytics",
    ],
  };

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" aria-label="CaseSync home">
          <span className="brand-mark"><Activity size={20} /></span>
          <span>AICTE <b>CaseSync</b><small>CASE COORDINATION PLATFORM</small></span>
        </a>
        <div className="topbar-right">
          <span className="demo-pill"><span /> DEMO ENVIRONMENT</span>
          <button className="button button-quiet" onClick={onSignOut}>Sign out</button>
        </div>
      </header>

      <main className="home-content">
        <div className="welcome-row">
          <div>
            <div className="eyebrow"><span className="eyebrow-line" /> WORKSPACE</div>
            <h1>Welcome to CaseSync</h1>
            <p className="muted">Your coordinated workspace for institution-related complaint cases.</p>
          </div>
          <div className="role-chip"><Icon size={16} /> {account.label}</div>
        </div>

        <section className="prototype-banner">
          <div className="banner-icon"><Sparkles size={20} /></div>
          <div>
            <strong>Foundation build · Part 1</strong>
            <p>This build establishes role-based entry and the UI foundation. Workflow modules will be added in the next steps.</p>
          </div>
        </section>

        <div className="section-heading">
          <div><h2>Your workspace</h2><p>Planned modules for this role</p></div>
          <span className="subtle-tag">ROADMAP</span>
        </div>

        <section className="module-grid">
          {nextSteps[role].map((item, index) => (
            <article className="module-card" key={item}>
              <div className="module-icon">
                {index === 0 ? <FileText size={19} /> : index === 1 ? <Activity size={19} /> : <ShieldCheck size={19} />}
              </div>
              <div className="module-number">MODULE 0{index + 1}</div>
              <h3>{item}</h3>
              <p>Planned for a later implementation step.</p>
              <div className="module-footer"><span>Not implemented yet</span><CircleHelp size={15} /></div>
            </article>
          ))}
        </section>

        <section className="integrity-note">
          <LockKeyhole size={18} />
          <div><strong>Prototype account notice</strong><p>Credentials are checked locally in this demo. There is no real authentication, shared database, or production security yet. Do not enter real personal or institutional data.</p></div>
        </section>
      </main>
      <footer className="footer">AICTE CaseSync <span>•</span> SIH frontend prototype <span>•</span> Part 1</footer>
    </div>
  );
}

export default function App() {
  const [selectedRole, setSelectedRole] = useState<Role>("institution");
  const [email, setEmail] = useState(accounts[0].email);
  const [password, setPassword] = useState(DEMO_PASSWORD);
  const [error, setError] = useState("");
  const [signedInRole, setSignedInRole] = useState<Role | null>(null);

  function chooseRole(account: DemoAccount) {
    setSelectedRole(account.role);
    setEmail(account.email);
    setPassword(DEMO_PASSWORD);
    setError("");
  }

  function handleLogin(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const match = accounts.find((account) =>
      account.role === selectedRole &&
      account.email.toLowerCase() === email.trim().toLowerCase() &&
      password === DEMO_PASSWORD
    );

    if (!match) {
      setError("Those demo credentials don't match the selected role. Choose a role or use its demo email.");
      return;
    }

    setError("");
    setSignedInRole(match.role);
  }

  if (signedInRole) {
    return <RoleHome role={signedInRole} onSignOut={() => setSignedInRole(null)} />;
  }

  return (
    <div className="login-page">
      <div className="login-orb orb-one" />
      <div className="login-orb orb-two" />
      <header className="login-header">
        <a className="brand" href="#" aria-label="CaseSync">
          <span className="brand-mark"><Activity size={20} /></span>
          <span>AICTE <b>CaseSync</b><small>CASE COORDINATION PLATFORM</small></span>
        </a>
        <span className="demo-pill"><span /> SIH PROTOTYPE</span>
      </header>

      <main className="login-layout">
        <section className="intro-panel">
          <div className="eyebrow"><span className="eyebrow-line" /> BUILT FOR CONNECTED GOVERNANCE</div>
          <h1>Every case.<br />One <span>connected</span><br />journey.</h1>
          <p className="intro-copy">A unified workspace concept for tracking institution-related complaints across bureaus and cells, with accountable handoffs and transparent progress.</p>

          <div className="intro-points">
            <div><span className="point-icon"><CheckCircle2 size={17} /></span><span><b>Clear ownership</b><small>Know who is responsible for the next action.</small></span></div>
            <div><span className="point-icon"><Activity size={17} /></span><span><b>Deadline awareness</b><small>Make delayed and at-risk work visible.</small></span></div>
            <div><span className="point-icon"><ShieldCheck size={17} /></span><span><b>Accountable decisions</b><small>Keep a traceable history of case actions.</small></span></div>
          </div>
          <div className="intro-footnote">Product concept for the Smart India Hackathon · Not an official AICTE service</div>
        </section>

        <section className="login-card">
          <div className="card-topline"><span>SECURE WORKSPACE</span><span className="lock-symbol"><LockKeyhole size={15} /></span></div>
          <h2>Sign in to CaseSync</h2>
          <p className="muted card-subtitle">Choose your demo role to continue.</p>

          <div className="role-options" aria-label="Choose demo role">
            {accounts.map((account) => {
              const Icon = account.icon;
              const active = selectedRole === account.role;
              return (
                <button key={account.role} type="button" className={`role-option ${active ? "active" : ""}`} onClick={() => chooseRole(account)} aria-pressed={active}>
                  <span className="role-icon"><Icon size={19} /></span>
                  <span className="role-copy"><b>{account.label}</b><small>{account.description}</small></span>
                  <span className="radio-indicator">{active && <span />}</span>
                </button>
              );
            })}
          </div>

          <form onSubmit={handleLogin}>
            <label htmlFor="email">Demo email</label>
            <input id="email" type="email" autoComplete="username" value={email} onChange={(event) => setEmail(event.target.value)} required />
            <label htmlFor="password">Demo password</label>
            <input id="password" type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} required />
            {error && <div className="form-error" role="alert">{error}</div>}
            <button className="button button-primary login-submit" type="submit">Enter workspace <ArrowRight size={17} /></button>
          </form>

          <div className="demo-credentials">
            <div className="credentials-heading"><span>DEMO ACCESS</span><span>PART 1</span></div>
            <p>Password for all three demo accounts: <code>casesync-demo</code></p>
            <div className="credential-list">
              {accounts.map((account) => (
                <button key={account.role} type="button" onClick={() => chooseRole(account)}><span>{account.label}</span><code>{account.email}</code></button>
              ))}
            </div>
          </div>
          <p className="prototype-disclaimer">Demo-only local role check · No real authentication or backend connected</p>
        </section>
      </main>
      <footer className="login-footer"><span>AICTE CaseSync</span><span>Designed as an SIH prototype</span><span>Part 1 · Foundation</span></footer>
    </div>
  );
}