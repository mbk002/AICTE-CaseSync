# AICTE CaseSync — SIH prototype

A React + TypeScript frontend prototype for demonstrating institution-related complaint coordination across AICTE bureaus/cells.

## Part 1: Project foundation and demo role login

Included:
- Vite + React + TypeScript scaffold
- Three demo roles: Institution, Bureau/Cell Officer, AICTE Administrator
- Role-specific demo credentials
- Responsive dark navy/teal interface
- Session is held in browser memory only (refresh returns to login)
- Clearly marked prototype/demo authentication

Not included yet: persistent shared database, real authentication, AI classification, cross-bureau tasks, SLA engine, duplicate matching, or production security. Those are added in later steps.

## Requirements
- Node.js 20+ recommended
- npm

## Run locally
```bash
npm install
npm run dev
```
Open the local URL printed by Vite.

## Demo accounts
All three accounts use the password `casesync-demo`:
- Institution: `institution@demo.casesync`
- Bureau officer: `officer@demo.casesync`
- AICTE administrator: `admin@demo.casesync`

These are demo-only accounts. The frontend checks the credentials locally; this is **not secure authentication** and must not be used for real personal or institutional data.

## Build check
```bash
npm run build
```

## Push to GitHub
Create an empty GitHub repository, then run:
```bash
git init
git add .
git commit -m "Part 1: CaseSync project foundation and demo login"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

## Project structure
```text
src/
  App.tsx       Main application and demo login
  index.css     Design system and responsive styling
  main.tsx      React entry point
```
